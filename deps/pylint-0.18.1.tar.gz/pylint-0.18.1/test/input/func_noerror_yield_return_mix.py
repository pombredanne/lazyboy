""" module doc """
__revision__ = None

def somegen():
    """this kind of mix is OK"""
    yield 1
    return
