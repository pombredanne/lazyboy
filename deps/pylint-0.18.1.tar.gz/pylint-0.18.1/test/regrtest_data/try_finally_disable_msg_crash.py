try:
    pass
finally:
    # pylint: disable-msg=W0201
    pass
