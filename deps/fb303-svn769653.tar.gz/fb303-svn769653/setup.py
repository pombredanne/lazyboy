# -*- coding: utf-8 -*-
#
# Cassandra
#
# © 2009 Digg, Inc. All rights reserved.
# Author: Ian Eure <ian@digg.com>
#

from setuptools import setup, find_packages

setup(name="fb303",
      version='svn769653',
      description="FB303 from Thrift contrib",
      url="http://incubator.apache.org/cassandra/",
      packages=find_packages(exclude=['ez_setup', 'examples', 'tests']),
      include_package_data=True,
      package_data = {'': ['*.thrift']},
      author="Ian Eure",
      author_email="ian@digg.com",
      scripts=['scripts/FacebookService-remote'],
      keywords="logging fb303",
      install_requires=['Thrift'],
      dependency_links=["http://github.com/ieure/python-cassandra/downloads"])
